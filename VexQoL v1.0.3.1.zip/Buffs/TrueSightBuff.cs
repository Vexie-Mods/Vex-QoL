using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria;
using Terraria.ModLoader;

namespace VexQoL.Buffs
{
	public class TrueSightBuff : ModBuff
	{
        public override void SetDefaults()
        {
            DisplayName.SetDefault("True Sight");
            Description.SetDefault("The abyss gazes into thee");
            Main.debuff[Type] = false;
            Main.pvpBuff[Type] = true;
            Main.buffNoSave[Type] = true;
            longerExpertDebuff = false;
        }

        // Greatly lights the player's position
        // Lights the position under the player's cursor
        public override void Update(Player player, ref int buffIndex)
        {
            Vector2 mousePos = Main.MouseWorld;
            Lighting.AddLight(mousePos, 1.0f, 1.0f, 1.0f);
            Lighting.AddLight(player.Center, 3.0f, 3.0f, 3.0f);
        }
    }
}