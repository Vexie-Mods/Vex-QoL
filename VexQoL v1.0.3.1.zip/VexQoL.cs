using Terraria.ModLoader;

namespace VexQoL
{
	class VexQoL : Mod
	{
		public VexQoL()
		{
			Properties = new ModProperties()
			{
				Autoload = true,
				AutoloadGores = true,
				AutoloadSounds = true
			};
		}
	}
}
