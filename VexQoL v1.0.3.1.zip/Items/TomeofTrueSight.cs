using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;

namespace VexQoL.Items
{
    public class TomeofTrueSight : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Tome of True Sight");
            Tooltip.SetDefault("Grants the user true sight at a horrible cost\n'Will not allow user to see upside-down'");
        }

        public override void SetDefaults()
        {
            item.magic = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 4;
            item.value = Terraria.Item.sellPrice(0, 3, 0, 0);
            item.rare = 10;
            item.UseSound = SoundID.Item100;
            item.autoReuse = false;

            item.mana = 200;
        }

        // Crafted at a workbench using:
        // 1 tome of improved site
        // 1 hunter potion
        // 1 spelunker potion
        // 5 souls of light
        // 5 souls of sight
        // 1 eye of the golem
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(mod, "TomeofImprovedSight", 1);
            recipe.AddIngredient(ItemID.HunterPotion, 1);
            recipe.AddIngredient(ItemID.TrapsightPotion, 1);
            recipe.AddIngredient(ItemID.SpelunkerPotion, 1);
            recipe.AddIngredient(ItemID.SoulofLight, 5);
            recipe.AddIngredient(ItemID.SoulofSight, 2);
            recipe.AddIngredient(ItemID.EyeoftheGolem, 1);

            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

        // You can alt use this item.
        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        // Gives the player the following buffs:
        //      Night owl buff
        //      Shine buff
        //      Dangersense buff
        //      Spelunker buff
        //      Hunter buff
        //      True sight buff (original to this mod)
        //
        // Gives the player the following debuffs:
        //      On fire
        //      Ichor
        //      Frostburn
        //      Electrified
        //      Bleeding
        //      Broken armor
        //      Burning
        //      Cursed inferno
        //      Darkness
        //      Horrified
        //      Poisoned
        //      Shadow flame
        //      Venom
        //      Weak
        //      Stoned
        //
        // Buffs last for one second for each point of mana spent
        // Debuffs last for one and a half seconds
        //
        // Right click the item to give the suspicious-looking tentacle buff as well
        public override bool UseItem(Player player)
        {
            player.statLife = player.statLife - player.statLifeMax2 / 2;

            if (player.statLife <= 0)
            {
                PlayerDeathReason damageSource = PlayerDeathReason.ByCustomReason(player.name + " couldn't handle the truth.");
                player.KillMe(damageSource, 1.0, 0, false);
                return true;
            }

            player.AddBuff(BuffID.NightOwl, 14400, true);
            player.AddBuff(BuffID.Shine, 14400, true);
            player.AddBuff(BuffID.Dangersense, 14400, true);
            player.AddBuff(BuffID.Spelunker, 14400, true);
            player.AddBuff(BuffID.Hunter, 14400, true);
            player.AddBuff(mod.GetBuff("TrueSightBuff").Type, 14400, true);

            if (player.altFunctionUse == 2)
            {
                player.AddBuff(BuffID.SuspiciousTentacle, 60, true);
            }

            const int TIME_DEBUFF = 90;

            player.AddBuff(BuffID.OnFire, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Ichor, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Frostburn, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Electrified, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Bleeding, TIME_DEBUFF, false);
            player.AddBuff(BuffID.BrokenArmor, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Burning, TIME_DEBUFF, false);
            player.AddBuff(BuffID.CursedInferno, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Darkness, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Horrified, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Poisoned, TIME_DEBUFF, false);
            player.AddBuff(BuffID.ShadowFlame, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Venom, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Weak, TIME_DEBUFF, false);
            player.AddBuff(BuffID.Stoned, TIME_DEBUFF, false);

            return true;
        }
    }
}
