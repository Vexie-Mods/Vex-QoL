using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.DataStructures;

namespace VexQoL.Items
{
    public class TomeofImprovedSight : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Tome of Improved Sight");
            Tooltip.SetDefault("Uses all remaining mana\nGrants improved vision\nSpending more mana gives longer durations");
        }

        public override void SetDefaults()
        {
            item.magic = true;
            item.width = 40;
            item.height = 40;
            item.useTime = 20;
            item.useAnimation = 20;
            item.useStyle = 4;
            item.value = Terraria.Item.sellPrice(0, 0, 33, 0);
            item.rare = 2;
            item.UseSound = SoundID.Item29;
            item.autoReuse = false;
        }

        // Crafted at a workbench using:
        // 1 book
        // 2 lenses
        // 1 blinkroot
        // 1 mana crystal
        // 1 night owl potion
        // 1 shine potion
        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Book, 1);
            recipe.AddIngredient(ItemID.Lens, 2);
            recipe.AddIngredient(ItemID.Blinkroot, 1);
            recipe.AddIngredient(ItemID.ManaCrystal, 1);
            recipe.AddIngredient(ItemID.NightOwlPotion, 1);
            recipe.AddIngredient(ItemID.ShinePotion, 1);
            recipe.AddTile(TileID.WorkBenches);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

        // You can alt use this item.
        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        // Gives the player night owl buff and shine buff
        // Lasts for one second for each point of mana spent
        // Right click the item to give the magic lantern buff as well
        public override bool UseItem(Player player)
        {
            int mana = player.statMana;

            player.statMana = 0;

            player.AddBuff(BuffID.NightOwl, mana * 60, true);
            player.AddBuff(BuffID.Shine, mana * 60, true);

            if (player.altFunctionUse == 2)
            {
                player.AddBuff(BuffID.MagicLantern, 60, true);
            }

            return true;
        }
    }
}
